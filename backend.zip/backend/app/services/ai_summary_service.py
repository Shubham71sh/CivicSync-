def generate_bill_analysis(text: str, file_name: str) -> Dict[str, Any]:
    """
    Calls the Gemini API to analyze the bill text and generate a structured JSON summary.
    Includes mock fallback data if the Gemini client is not initialized.
    """

    client = get_gemini_client()

    # Truncate text to avoid model token limits
    truncated_text = text[:30000]

    prompt = f"""
You are an expert civic policy advisor and legislative analyst.

Analyze the following legislative bill text extracted from '{file_name}'.

Return ONLY valid JSON.

Bill Text:
{truncated_text}
"""

    if client is None:
        logger.warning("Gemini Client not available. Using mock bill analysis.")
        return get_mock_bill_analysis(file_name)

    try:
        logger.info(f"Client: {client}")
        logger.info("Calling Gemini...")
        logger.info("Model: gemini-2.5-flash")

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        response_text = response.text.strip()

        if response_text.startswith("```json"):
            response_text = response_text[7:]

        if response_text.endswith("```"):
            response_text = response_text[:-3]

        response_text = response_text.strip()

        analysis = json.loads(response_text)

        logger.info(f"Successfully generated AI summary for {file_name}")

        return {
            "title": analysis.get("title", file_name.replace(".pdf", "").title()),
            "billNumber": analysis.get("billNumber", "GEN-2026"),
            "summary": analysis.get("summary", ""),
            "keyPoints": analysis.get("keyPoints", []),
            "impactScore": int(analysis.get("impactScore", 50)),
            "userImpact": analysis.get("userImpact", ""),
            "tags": analysis.get("tags", []),
            "status": "pending"
        }

    except Exception:
        logger.exception("Gemini API request failed")
        return get_mock_bill_analysis(file_name)